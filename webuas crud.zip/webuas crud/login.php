<?php
session_start();
$koneksi = new mysqli("localhost", "root", "", "kampus", 3307);

// Jika sudah login, langsung alihkan ke index
if (isset($_SESSION['login'])) {
  header("Location: index.php");
  exit;
}

$error = "";

if (isset($_POST['login'])) {
  $username = trim($_POST['username']);
  $password = trim($_POST['password']);

  $sql = "SELECT * FROM user WHERE username='$username'";
  $result = $koneksi->query($sql);

  if ($result && $result->num_rows === 1) {
    $user = $result->fetch_assoc();
    if (password_verify($password, $user['password'])) {
      $_SESSION['login'] = true;
      $_SESSION['username'] = $username;
      header("Location: index.php");
      exit;
    } else {
      $error = "Password salah.";
    }
  } else {
    $error = "Username tidak ditemukan.";
  }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Login</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-r from-indigo-50 via-purple-50 to-pink-50 min-h-screen flex items-center justify-center">
  <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
    <h2 class="text-2xl font-bold text-center text-indigo-700 mb-6">Login to Your Account</h2>
    <?php if ($error): ?>
      <div class="bg-red-100 text-red-700 p-2 rounded mb-4 text-sm text-center"><?= $error ?></div>
    <?php endif; ?>
    <form method="post" class="space-y-4">
      <div>
        <label class="block text-sm font-medium text-gray-700">Username</label>
        <input type="text" name="username" required class="mt-1 block w-full px-3 py-2 border border-indigo-300 rounded-md shadow-sm" />
      </div>
      <div>
        <label class="block text-sm font-medium text-gray-700">Password</label>
        <input type="password" name="password" required class="mt-1 block w-full px-3 py-2 border border-indigo-300 rounded-md shadow-sm" />
      </div>
      <button type="submit" name="login" class="w-full bg-indigo-600 text-white py-2 rounded-md hover:bg-indigo-700 font-semibold">Login</button>
      <div class="text-center mt-3">
        <p>belum punya akun?<a href="sign_up.php">Sign Up</a></p>
      </div>
    </form>
  </div>
</body>
</html>
