document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('mahasiswaForm');
  const tableBody = document.querySelector('#dataTable tbody');
  const searchInput = document.getElementById('searchInput');
  const searchBtn = document.getElementById('searchBtn');

  let editIndex = null;

  function getData() {
    return JSON.parse(localStorage.getItem('mahasiswa')) || [];
  }

  function saveData(data) {
    localStorage.setItem('mahasiswa', JSON.stringify(data));
  }

  function renderTable(data) {
    tableBody.innerHTML = '';
    data.forEach((mhs, i) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td class="number">${i + 1}</td>
        <td>${mhs.nim}</td>
        <td>${mhs.nama}</td>
        <td>${mhs.alamat}</td>
        <td>${mhs.fakultas}</td>
        <td class="aksi">
          <button class="btn btn-warning" data-index="${i}">Edit</button>
          <button class="btn btn-danger" data-delete="${i}">Hapus</button>
        </td>
      `;
      tableBody.appendChild(tr);
    });
  }

  function clearForm() {
    document.getElementById('nim').value = '';
    document.getElementById('nama').value = '';
    document.getElementById('alamat').value = '';
    document.getElementById('fakultas').value = '';
    editIndex = null;
  }
  searchInput.value = '';

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const mhs = {
      nim: form.nim.value.trim(),
      nama: form.nama.value.trim(),
      alamat: form.alamat.value.trim(),
      fakultas: form.fakultas.value,
    };

    if (!form.checkValidity()) return;

    const data = getData();

    if (editIndex !== null) {
      data[editIndex] = mhs;
    } else {
      // prevent duplicate NIM
      if (data.some(d => d.nim === mhs.nim)) {
        alert('NIM sudah terdaftar!');
        return;
      }
      data.push(mhs);
    }

    saveData(data);
    renderTable(data);
    clearForm();
  });

  tableBody.addEventListener('click', e => {
    const editBtn = e.target.closest('[data-index]');
    const deleteBtn = e.target.closest('[data-delete]');

    if (editBtn) {
      const index = +editBtn.dataset.index;
      const data = getData()[index];
      form.nim.value = data.nim;
      form.nama.value = data.nama;
      form.alamat.value = data.alamat;
      form.fakultas.value = data.fakultas;
      editIndex = index;
    }

    if (deleteBtn) {
      const index = +deleteBtn.dataset.delete;
      if (confirm('Yakin ingin menghapus data ini?')) {
        const data = getData();
        const nama = data[index].nama;
        data.splice(index, 1);
        saveData(data);
        renderTable(data);
        alert(`Data ${nama} dihapus.`);
      }
    }
  });

  searchBtn.addEventListener('click', () => {
    const query = searchInput.value.toLowerCase();
    const filtered = getData().filter(m =>
      m.nim.toLowerCase().includes(query) || m.nama.toLowerCase().includes(query)
    );
    renderTable(filtered);
  });

  // render awal
  renderTable(getData());
});

// Menghilangkan alert otomatis setelah 3 detik
setTimeout(() => {
  const alertBox = document.getElementById('alert-box');
  if (alertBox) {
    alertBox.style.display = 'none';
  }
}, 3000);

document.addEventListener('DOMContentLoaded', function () {
  const alertBox = document.getElementById('alert-box');
  if (alertBox) {
    setTimeout(() => {
      alertBox.style.display = 'none';
    }, 3000); // Hilang dalam 3 detik
  }
});


