<?php
session_start();
if (!isset($_SESSION['login'])) {
  header("Location: login.php");
  exit;
}

$koneksi = new mysqli("localhost", "root", "", "kampus", 3306);

$error = $sukses = "";
$nama_fakultas = $kaprodi = "";
$op = $_GET['op'] ?? "";

if ($op == 'edit') {
  $id = $_GET['id'];
  $result = $koneksi->query("SELECT * FROM fakultas WHERE id_fakultas='$id'");
  if ($result && $result->num_rows > 0) {
    $data = $result->fetch_assoc();
    $nama_fakultas = $data['nama_fakultas'];
    $kaprodi = $data['kaprodi'];
  } else {
    $error = "Data tidak ditemukan";
  }
}

if ($op == 'delete') {
  $id = $_GET['id'];

  // Cek apakah ada mahasiswa yang memakai id_fakultas ini
  $relasi = $koneksi->query("SELECT * FROM mahasiswa WHERE id_fakultas='$id'");

  if ($relasi && $relasi->num_rows > 0) {
    $error = "Tidak dapat menghapus karena fakultas masih digunakan di data mahasiswa.";
  } else {
    $q = $koneksi->query("DELETE FROM fakultas WHERE id_fakultas='$id'");
    $sukses = $q ? "Berhasil menghapus data" : "Gagal menghapus data";
  }
}

if (isset($_POST['simpan'])) {
  $nama_fakultas = $_POST['nama_fakultas'];
  $kaprodi = $_POST['kaprodi'];

  if ($nama_fakultas && $kaprodi) {
    if ($op == 'edit') {
      $id = $_GET['id'];
      $q = $koneksi->query("UPDATE fakultas SET nama_fakultas='$nama_fakultas', kaprodi='$kaprodi' WHERE id_fakultas='$id'");
    } else {
      // Cari ID fakultas kosong terkecil
      $cek_id = $koneksi->query("SELECT id_fakultas + 1 AS calon_id FROM fakultas 
        WHERE NOT EXISTS (
          SELECT 1 FROM fakultas AS f2 WHERE f2.id_fakultas = fakultas.id_fakultas + 1
        ) ORDER BY id_fakultas LIMIT 1");

      $hasil = $cek_id->fetch_assoc();
      $calon_id = $hasil && $hasil['calon_id'] ? $hasil['calon_id'] : 1;

      $q = $koneksi->query("INSERT INTO fakultas (id_fakultas, nama_fakultas, kaprodi) VALUES ('$calon_id', '$nama_fakultas', '$kaprodi')");
    }

    if ($q) {
      $sukses = ($op == 'edit') ? "Data berhasil diupdate" : "Berhasil menambahkan data";
      $nama_fakultas = $kaprodi = "";
      $op = "";
    } else {
      $error = "Gagal menyimpan data";
    }
  } else {
    $error = "Semua field wajib diisi";
  }
}

$data_fakultas = $koneksi->query("SELECT * FROM fakultas ORDER BY id_fakultas");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Manajemen Fakultas</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body class="container py-5">
  <h2 class="mb-4">Manajemen Fakultas</h2>
  <a href="index.php" class="btn btn-secondary mb-3">← Kembali ke Mahasiswa</a>

  <?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= $error ?></div>
  <?php elseif (!empty($sukses)): ?>
    <div class="alert alert-success" id="alert-box"><?= $sukses ?></div>
  <?php endif; ?>

  <form method="post" class="row g-3 mb-4">
    <div class="col-md-6">
      <input type="text" name="nama_fakultas" value="<?= $nama_fakultas ?>" class="form-control" placeholder="Nama Fakultas" required>
    </div>
    <div class="col-md-6">
      <input type="text" name="kaprodi" value="<?= $kaprodi ?>" class="form-control" placeholder="Nama Kaprodi" required>
    </div>
    <div class="col-12">
      <button class="btn btn-primary" name="simpan">Simpan</button>
    </div>
  </form>

  <table class="table table-bordered table-striped">
    <thead class="table-primary">
      <tr class="text-center">
        <th>ID</th>
        <th>Nama Fakultas</th>
        <th>Nama Kaprodi</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $data_fakultas->fetch_assoc()): ?>
        <tr>
          <td class="text-center"><?= $row['id_fakultas'] ?></td>
          <td><?= $row['nama_fakultas'] ?></td>
          <td><?= $row['kaprodi'] ?></td>
          <td class="text-center">
            <a href="?op=edit&id=<?= $row['id_fakultas'] ?>" class="btn btn-warning btn-sm">Edit</a>
            <a href="?op=delete&id=<?= $row['id_fakultas'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</body>
</html>
