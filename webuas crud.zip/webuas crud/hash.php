<?php
$password = "45678";

// Generate hash
$hash = password_hash($password, PASSWORD_DEFAULT);

// Tampilkan hasil
echo "Password asli : " . $password . "<br>";
echo "Hash password : " . $hash;
?>
