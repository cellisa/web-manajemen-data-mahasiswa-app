<?php
// Proses jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = new mysqli("localhost", "root", "", "kampus", 3306);

    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm  = $_POST['confirm-password'];

    if ($password !== $confirm) {
        $error = "Password dan Konfirmasi tidak sama!";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $check = $conn->query("SELECT * FROM user WHERE username = '$username'");
        
        if ($check->num_rows > 0) {
            $error = "Username sudah digunakan!";
        } else {
            $sql = "INSERT INTO user (username, password) VALUES ('$username', '$hash')";
            if ($conn->query($sql) === TRUE) {
                $success = "Pendaftaran berhasil! <a href='login.php'>Login sekarang</a>";
            } else {
                $error = "Terjadi kesalahan: " . $conn->error;
            }
        }
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Sign Up</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-5">
      <h3 class="text-center mb-4">Sign Up</h3>

      <!-- Alert -->
      <?php if (isset($error)) : ?>
        <div class="alert alert-danger"><?= $error ?></div>
      <?php elseif (isset($success)) : ?>
        <div class="alert alert-success"><?= $success ?></div>
      <?php endif; ?>

      <!-- Form -->
      <form method="POST" action="">
        <div class="mb-3">
          <label class="form-label">Username</label>
          <input type="text" name="username" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Konfirmasi Password</label>
          <input type="password" name="confirm-password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Sign Up</button>
      </form>

      <div class="text-center mt-3">
        <p>Sudah punya akun? <a href="login.php">Login di sini</a></p>
      </div>
    </div>
  </div>
</div>

</body>
</html>
