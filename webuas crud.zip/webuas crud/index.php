<?php
session_start();
if (!isset($_SESSION['login'])) {
  header("Location: login.php");
  exit;
}

$host = "localhost";
$user = "root";
$pass = "";
$db = "kampus";
$port = 3307;

$koneksi = mysqli_connect($host, $user, $pass, $db, $port);
if (!$koneksi) {
  die("Koneksi ke database gagal");
}

// Ambil data fakultas dari tabel fakultas
$fakultasList = [];
$sql_fak = "SELECT * FROM fakultas";
$result_fak = mysqli_query($koneksi, $sql_fak);
while ($row = mysqli_fetch_assoc($result_fak)) {
    $fakultasList[] = $row;
}

$nim = "";
$nama = "";
$alamat = "";
$fakultas = "";
$sukses = "";
$error = "";

$op = $_GET['op'] ?? "";

if ($op == 'delete') {
  $id = $_GET['id'];
  $sql1 = "DELETE FROM mahasiswa WHERE nim = '$id'";
  $q1 = mysqli_query($koneksi, $sql1);
  $sukses = $q1 ? "Berhasil menghapus data" : "Gagal menghapus data";
}

if ($op == 'edit') {
  $id = $_GET['id'];
  $sql1 = "SELECT * FROM mahasiswa WHERE id = '$id'";
  $q1 = mysqli_query($koneksi, $sql1);
  $r1 = mysqli_fetch_array($q1);
  $nim = $r1['nim'];
  $nama = $r1['nama'];
  $alamat = $r1['alamat'];
  $fakultas = $r1['fakultas'];

  if ($nim == '') {
    $error = "Data tidak ditemukan";
  }
}

if (isset($_POST['simpan'])) {
  $nim = $_POST['nim'];
  $nama = $_POST['nama'];
  $alamat = $_POST['alamat'];
  $fakultas = $_POST['id_fakultas'];

  if ($nim && $nama && $alamat && $fakultas) {
    if ($op == 'edit') {
      $sql1 = "UPDATE mahasiswa SET nim='$nim', nama='$nama', alamat='$alamat', fakultas='$fakultas' WHERE id='$id'";
    } else {
      $sql1 = "INSERT INTO mahasiswa(nim, nama, alamat, fakultas) VALUES ('$nim', '$nama', '$alamat', '$fakultas')";
    }
    $q1 = mysqli_query($koneksi, $sql1);
    $sukses = $q1 ? ($op == 'edit' ? "Data berhasil diupdate" : "Berhasil memasukkan data baru") : ($op == 'edit' ? "Data gagal diupdate" : "Gagal memasukkan data");
  } else {
    $error = "Silakan masukkan semua data";
  }
}

$query = isset($_GET['cari']) ? "SELECT * FROM mahasiswa WHERE nim LIKE '%" . $_GET['cari'] . "%' OR nama LIKE '%" . $_GET['cari'] . 
"%'" : "SELECT * FROM mahasiswa";
$tampil = mysqli_query($koneksi, $query);
if (!$tampil) die("Query error: " . mysqli_error($koneksi));

?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>CRUD Mahasiswa</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
</head>
<body style="font-family: 'Poppins', sans-serif; background-image: url('images/kampus.jpg'); background-size: cover; background-position: 
  center; min-height: 100vh;">
  <div class="container py-5">
    <div class="bg-white p-4 rounded shadow">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="fw-bold text-primary">Sistem Manajemen Data Mahasiswa</h2>
        <div>
          <a href="menu_fakultas.php" class="btn btn-outline-primary me-2">📋 Kelola Fakultas</a>
          <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
      </div>

      <?php if (!empty($error)): ?>
        <div class="alert alert-danger" id="alert-box"><?= $error ?></div>
      <?php elseif (!empty($sukses)): ?>
        <div class="alert alert-success" id="alert-box"><?= $sukses ?></div>
      <?php endif; ?>

      <form method="post" class="row g-3 mb-4">
        <div class="col-md-6">
          <label for="nim" class="form-label">NIM</label>
          <input type="text" class="form-control" id="nim" name="nim" value="<?= $nim ?>" required>
        </div>
        <div class="col-md-6">
          <label for="nama" class="form-label">Nama</label>
          <input type="text" class="form-control" id="nama" name="nama" value="<?= $nama ?>" required>
        </div>
        <div class="col-md-6">
          <label for="alamat" class="form-label">Alamat</label>
          <input type="text" class="form-control" id="alamat" name="alamat" value="<?= $alamat ?>" required>
        </div>
        <div class="col-md-6">
          <label for="fakultas" class="form-label">Fakultas</label>
          <select name="id_fakultas" class="form-control" required>
            <option value="">- Pilih Fakultas -</option>
            <?php foreach ($fakultasList as $f) : ?>
              <option value="<?= $f['nama_fakultas'] ?>" <?= ($fakultas == $f['nama_fakultas']) ? 'selected' : '' ?>>
                <?= $f['nama_fakultas'] ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-12">
          <button type="submit" name="simpan" class="btn btn-primary me-2">💾 Simpan Data</button>
          <a href="pdf.php" target="_blank" class="btn btn-danger">📥 Download PDF</a>
        </div>
      </form>

      <form method="get" class="d-flex mb-4">
        <input type="text" name="cari" class="form-control me-2" placeholder="Cari nama atau NIM...">
        <button type="submit" class="btn btn-success">Cari</button>
        <?php if (isset($_GET['cari']) && $_GET['cari'] != ''): ?>
          <a href="index.php" class="btn btn-outline-danger">✖</a>
        <?php endif; ?>
      </form>

      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>No</th>
              <th>NIM</th>
              <th>Nama</th>
              <th>Alamat</th>
              <th>Fakultas</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php $urut = 1; ?>
            <?php while ($data = mysqli_fetch_array($tampil)) : ?>
              <tr>
                <th><?= $urut++ ?></th>
                <td><?= $data['nim'] ?></td>
                <td><?= $data['nama'] ?></td>
                <td><?= $data['alamat'] ?></td>
                <td><?= $data['fakultas'] ?></td>
                <td>
                  <a href="index.php?op=edit&id=<?= $data['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                  <a href="index.php?op=delete&id=<?= $data['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm
                  ('Yakin ingin menghapus data ini?')">Delete</a>
                </td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
