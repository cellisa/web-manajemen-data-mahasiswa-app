<?php
session_start();
if (!isset($_SESSION['login'])) {
  header("Location: login.php");
  exit;
}

$koneksi = new mysqli("localhost", "root", "", "kampus", 3307);

$id = $_GET['id'] ?? '';
$nama_fakultas = $kaprodi = "";
$sukses = $error = "";

// Ambil data fakultas berdasarkan ID
if ($id != "") {
  $result = $koneksi->query("SELECT * FROM fakultas WHERE id_fakultas='$id'");
  if ($result && $result->num_rows > 0) {
    $data = $result->fetch_assoc();
    $nama_fakultas = $data['nama_fakultas'];
    $kaprodi = $data['kaprodi'];
  } else {
    $error = "Data tidak ditemukan";
  }
} else {
  header("Location: menu_fakultas.php");
  exit;
}

// Proses update
if (isset($_POST['simpan'])) {
  $nama_fakultas = $_POST['nama_fakultas'];
  $kaprodi = $_POST['kaprodi'];
  
  if ($nama_fakultas && $kaprodi) {
    $update = $koneksi->query("UPDATE fakultas SET nama_fakultas='$nama_fakultas', kaprodi='$kaprodi' WHERE id_fakultas='$id'");
    if ($update) {
      header("Location: menu_fakultas.php?pesan=update_sukses");
      exit;
    } else {
      $error = "Gagal memperbarui data";
    }
  } else {
    $error = "Semua field wajib diisi";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Edit Fakultas</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body class="container py-5">
  <h3>Edit Fakultas</h3>
  <a href="menu_fakultas.php" class="btn btn-secondary mb-3">← Kembali</a>

  <?php if ($error): ?>
    <div class="alert alert-danger"><?= $error ?></div>
  <?php endif; ?>

  <form method="post" class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Nama Fakultas</label>
      <input type="text" class="form-control" name="nama_fakultas" value="<?= $nama_fakultas ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Nama Kaprodi</label>
      <input type="text" class="form-control" name="kaprodi" value="<?= $kaprodi ?>" required>
    </div>
    <div class="col-12">
      <button type="submit" name="simpan" class="btn btn-primary">Simpan Perubahan</button>
    </div>
  </form>
</body>
</html>
