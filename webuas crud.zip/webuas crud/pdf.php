<?php
ob_start(); // Hindari output sebelum PDF
session_start();

// Koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "kampus", 3307);

// Cek koneksi
if (mysqli_connect_errno()) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Load TCPDF
require_once('tcpdf/tcpdf.php');

// Buat class PDF
class PDF extends TCPDF {
    public function Header() {
        // Logo kampus
        $this->Image('logo kampus.jpg', 20, 5, 20); // Ubah sesuai lokasi logo

        // Judul institusi
        $this->SetFont('helvetica', 'B', 14);
        $this->Cell(0, 8, 'INSTITUT TEKNOLOGI BISNIS AAS INDONESIA', 0, 1, 'C');

        // Alamat
        $this->SetFont('helvetica', '', 9);
        $alamat = "Jl. Slamet Riyadi No.361, Windan, Makamhaji, Kartasura, Kabupaten Sukoharjo,\nJawa Tengah, 57161, Indonesia | Telp: (+62) 1234 456 77";
        $this->MultiCell(0, 5, $alamat, 0, 'C');

        // Garis bawah
        $this->Line(10, 28, 287, 28);
        $this->Ln(5);
    }

    public function Footer() {
        $this->SetY(-40);
        $this->SetFont('helvetica', '', 10);
        $this->Cell(0, 10, 'Solo, ' . date('d F Y'), 0, 1, 'R');
        $this->Cell(0, 6, 'Rektor / Ketua Yayasan,', 0, 1, 'R');
        $this->Ln(12);
        $this->Cell(0, 6, '( Nama Rektor )', 0, 0, 'R');
    }
}

// Buat objek PDF
$pdf = new PDF('L', PDF_UNIT, 'A4', true, 'UTF-8', false);
$pdf->SetCreator('AAS CRUD App');
$pdf->SetAuthor('Admin Kampus');
$pdf->SetTitle('Data Mahasiswa');
$pdf->SetSubject('Laporan Mahasiswa');
$pdf->SetKeywords('PDF, Mahasiswa, AAS');

// Pengaturan PDF
$pdf->SetMargins(15, 30, 15);
$pdf->SetAutoPageBreak(TRUE, 25);
$pdf->SetFont('times', '', 11);
$pdf->setPrintHeader(true);
$pdf->setPrintFooter(true);

// Tambah halaman
$pdf->AddPage();

// Query data mahasiswa + fakultas
$query = mysqli_query($koneksi, "
    SELECT m.nim, m.nama, m.alamat, f.nama_fakultas
    FROM mahasiswa m
    LEFT JOIN fakultas f ON m.id_fakultas = f.id_fakultas
    ORDER BY m.nama ASC
");

// Mulai isi tabel
$html = '
<h2 style="text-align:center;">Data Mahasiswa</h2><br>
<table border="1" cellpadding="6" cellspacing="0" width="100%">
    <thead>
        <tr style="background-color:#f2f2f2; font-weight:bold; text-align:center;">
            <th width="10%">No</th>
            <th width="20%">NIM</th>
            <th width="20%">Nama</th>
            <th width="20%">Alamat</th>
            <th width="20%">Fakultas</th>
        </tr>
    </thead>
    <tbody>';

$no = 1;
$query = mysqli_query($koneksi, "SELECT * FROM mahasiswa");
while ($row = mysqli_fetch_assoc($query)) {
    $html .= '<tr>
        <td style="text-align:center; vertical-align:middle; width:10%;">' . $no++ . '</td>
        <td style="text-align:center; vertical-align:middle;">' . $row['nim'] . '</td>
        <td style="vertical-align:middle;">' . $row['nama'] . '</td>
        <td style="vertical-align:middle;">' . $row['alamat'] . '</td>
        <td style="vertical-align:middle;">' . $row['fakultas'] . '</td>
    </tr>';
}
$html .= '</tbody></table>';

// Tulis ke PDF
$pdf->writeHTML($html, true, false, true, false, '');

// Output file PDF
ob_end_clean(); // Bersihkan output buffer sebelum kirim PDF
$pdf->Output('data_mahasiswa.pdf', 'D'); // D = Download
?>
